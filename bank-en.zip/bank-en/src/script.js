// Messages to display in sequence
const messages = [
    "Hi, my name is Abdulaziz",
    "and I'm here to help you "
];

const textDisplay = document.getElementById("textDisplay");
let currentMessageIndex = 0;
let charIndex = 0;
const typingSpeed = 100; // Speed of typing in ms
const displayTime = 2000; // Time to display each full message before disappearing in ms

function typeText() {
    if (charIndex < messages[currentMessageIndex].length) {
        textDisplay.innerHTML += messages[currentMessageIndex].charAt(charIndex);
        charIndex++;
        setTimeout(typeText, typingSpeed);
    } else if (currentMessageIndex < messages.length - 1) {
        setTimeout(() => {
            textDisplay.innerHTML = ""; 
            charIndex = 0;
            currentMessageIndex++;
            setTimeout(typeText, typingSpeed); 
        }, displayTime);
    }
}

window.onload = typeText;

// Loan calculator functionality
document.getElementById('calculateBtn').addEventListener('click', function() {
    const salary = parseFloat(document.getElementById('salary').value);
    const loanAmountInput = document.getElementById('loanAmount').value;
    const nationality = document.getElementById('nationality').value;
    const duration = parseInt(document.getElementById('duration').value);
    const loanWarning = document.getElementById("loanWarning");

    if (!salary || !duration || !nationality) {
        alert("Please fill in all required fields.");
        return;
    }

    let interestRate;
    const maxDeduction = salary * 0.3333;

    if (nationality === 'saudi') {
        if (salary >= 5000 && salary < 10000) {
            interestRate = 0.0349;
        } else if (salary >= 10000 && salary < 20000) {
            interestRate = 0.0264;
        } else if (salary >= 20000) {
            interestRate = 0.0229;
        } else {
            alert("Salary must be at least 5000 SR for Saudi nationals.");
            return;
        }
    } else if (nationality === 'non_saudi') {
        if (salary >= 3000 && salary < 5000) {
            interestRate = 0.0675;
        } else if (salary >= 5000) {
            interestRate = 0.06;
        } else {
            alert("Salary must be at least 3000 SR for non-Saudi nationals.");
            return;
        }
    }

    const totalPaybackCap = maxDeduction * duration;
    const maxLoanAmount = totalPaybackCap / (1 + (interestRate * (duration / 12)));
    const loanAmount = loanAmountInput ? parseFloat(loanAmountInput) : maxLoanAmount;

    if (loanAmountInput && loanAmount > maxLoanAmount) {
        loanWarning.classList.remove("hidden");
        return;
    } else {
        loanWarning.classList.add("hidden");
    }

    const profitAmount = loanAmount * (interestRate * (duration / 12));
    const totalRepayment = loanAmount + profitAmount;
    const monthlyInstallment = totalRepayment / duration;

    document.getElementById('resultLoanAmount').textContent = loanAmount.toFixed(2);
    document.getElementById('resultMonthlyInstallment').textContent = monthlyInstallment.toFixed(2);
    document.getElementById('resultProfitAmount').textContent = profitAmount.toFixed(2);
    document.getElementById('resultTotalPayback').textContent = totalRepayment.toFixed(2);

    document.getElementById('results').classList.remove('hidden');
    document.getElementById('results').scrollIntoView({ behavior: "smooth" });

    const message = `Hi! I'm interested in the loan offer:\n- Loan Amount: ${loanAmount.toFixed(2)} SR\n- Monthly Installment: ${monthlyInstallment.toFixed(2)} SR\n- Bank Profit: ${profitAmount.toFixed(2)} SR\n- Total Loan: ${totalRepayment.toFixed(2)} SR\n\nPlease contact me for further details!`;
    const whatsappLink = `https://wa.me/966537137038?text=${encodeURIComponent(message)}`;

    const whatsappMessage = document.getElementById('whatsappMessage');
    whatsappMessage.className = "whatsapp-message";
    whatsappMessage.innerHTML = `Send your preferred offer to Abdulaziz now! 👍 ❤️<br>
    <a href="${whatsappLink}" target="_blank">Contact via WhatsApp: Click Here</a>`;
    whatsappMessage.classList.remove('hidden');
});
